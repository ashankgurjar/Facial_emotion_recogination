import streamlit as st
from PIL import Image
from transformers import pipeline
import torch

st.set_page_config(page_title="Facial Emotion Recognition", page_icon="🙂", layout="centered")

st.title("🙂 Facial Emotion Recognition")
st.write(
    "Upload a photo containing a face. This demo uses a pretrained image-classification "
    "model to estimate facial-expression labels."
)
st.info(
    "Educational demo only: facial-expression predictions can be inaccurate and do not "
    "reliably reveal a person's true feelings, personality, or intentions."
)

@st.cache_resource
def load_model():
    device = 0 if torch.cuda.is_available() else -1
    return pipeline(
        task="image-classification",
        model="trpakov/vit-face-expression",
        device=device,
    )

uploaded_file = st.file_uploader("Choose a face image", type=["jpg", "jpeg", "png", "webp"])

if uploaded_file:
    try:
        image = Image.open(uploaded_file).convert("RGB")
        st.image(image, caption="Uploaded image", use_container_width=True)

        if st.button("Predict Expression", type="primary", use_container_width=True):
            with st.spinner("Loading model and analyzing image..."):
                classifier = load_model()
                results = classifier(image, top_k=5)

            st.subheader("Prediction results")
            if results:
                best = results[0]
                st.metric("Top label", best["label"].replace("_", " ").title(),
                          f'{best["score"] * 100:.1f}% model score')
                st.caption("Scores are model confidence scores, not a measurement of someone's actual emotional state.")

                st.write("Other model predictions")
                for item in results:
                    label = item["label"].replace("_", " ").title()
                    score = float(item["score"])
                    st.write(f"**{label}** — {score * 100:.1f}%")
                    st.progress(max(0.0, min(1.0, score)))
            else:
                st.warning("The model returned no predictions. Try another clear image.")
    except Exception as exc:
        st.error("Could not read or analyze this image.")
        st.caption("Check that the file is a valid image and that the app has an internet connection for the first model download.")
        with st.expander("Technical details"):
            st.code(str(exc))

st.divider()
st.caption("Mini-project: Python + Streamlit + Hugging Face Transformers + PyTorch")
