# Facial Emotion Recognition — Deep Learning Mini-Project

A beginner-friendly Streamlit website that uses a pretrained Vision Transformer model to classify facial-expression labels from an uploaded image.

## Important note

This is an educational image-classification demo. Facial expressions do **not** reliably reveal a person's actual feelings, personality, intentions, or mental state. Do not use predictions to make consequential decisions about people.

## Features

- Upload JPG, JPEG, PNG, or WEBP images
- Predict button and top predicted expression label
- Displays the top five model labels and scores
- Simple Streamlit interface
- Uses a pretrained model; no training dataset is required to run the demo

## Run on a computer

1. Install Python 3.10 or 3.11.
2. Extract this ZIP folder.
3. Open a terminal inside the project folder.
4. Install packages:

   ```bash
   pip install -r requirements.txt
   ```

5. Start the website:

   ```bash
   streamlit run app.py
   ```

6. Open the local URL printed in the terminal, usually `http://localhost:8501`.

The first prediction downloads the pretrained model, so an internet connection is needed. Model download and inference may take a few minutes.

## Run using only an Android phone

A straightforward option is to deploy the project using Streamlit Community Cloud from your phone's browser:

1. Extract the ZIP.
2. Create a GitHub repository and upload `app.py`, `requirements.txt`, and `README.md`.
3. Open Streamlit Community Cloud and sign in with GitHub.
4. Create a new app, choose your repository, and set the main file to `app.py`.
5. Deploy and wait for the model/dependencies to finish installing.

Cloud providers can change their free-tier limits. Large dependencies such as PyTorch may take time to install. If deployment fails, check the build logs.

## How it works

1. Streamlit accepts an uploaded image.
2. Pillow converts it to RGB format.
3. Hugging Face Transformers loads the pretrained `trpakov/vit-face-expression` image-classification model.
4. PyTorch runs inference on the image.
5. The app displays the model's top labels and scores.

## Suggested project report sections

- Title and abstract
- Problem statement and objectives
- Tools and technologies
- System workflow
- Model overview (Vision Transformer)
- Implementation and screenshots
- Testing and observations
- Limitations, privacy, and ethical considerations
- Conclusion and future scope

## Viva questions

1. **What is deep learning?** A machine-learning approach that uses neural networks with multiple layers.
2. **What is a pretrained model?** A model trained previously on a dataset and reused for a related task.
3. **What is a Vision Transformer (ViT)?** A neural-network architecture that processes image patches using transformer attention.
4. **What is Streamlit?** A Python framework for building interactive data and ML apps.
5. **What does a confidence score mean?** A model score for a predicted label; it is not proof that the label is correct.
6. **What are the limitations?** Results can be affected by lighting, pose, image quality, training-data bias, and expressions that do not match the model's learned patterns.
7. **Can this app know a person's true feelings?** No. It predicts a visual label and cannot reliably determine a person's internal emotional state.

## Files

- `app.py` — Streamlit website and prediction logic
- `requirements.txt` — Python dependencies
- `README.md` — setup instructions and project documentation
